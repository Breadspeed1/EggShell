import turtle
screen = turtle.Screen()
screen.title("DVD Logo Screensaver")
screen.bgcolor("blue")
screen.screensize()
screen.setup(width = 800, height = 600)
# dvd logo
screen.register_shape('dvdlogo.gif')
dvd = turtle.Turtle()
dvd.speed(0)
dvd.shape("dvdlogo.gif")
dvd.color("black")
dvd.penup()
dvd.goto(0,0)
speed = 5
dvd.dx = speed
dvd.dy = speed
cornerhits = 0

#pen
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(-380,250)
pen.write("Corner Hits: {}".format(cornerhits), font=("arial", 24))

# main loop
while True:
    screen.update()

    dvd.setx(dvd.xcor() + dvd.dx)
    dvd.sety(dvd.ycor() + dvd.dy)

    if (dvd.xcor() >= 285):
        dvd.dx = dvd.dx * -1

    if (dvd.xcor() <= -285):
        dvd.dx = dvd.dx * -1

    if (dvd.ycor() >= 235):
        dvd.dy = dvd.dy * -1

    if (dvd.ycor() <= -225):
        dvd.dy = dvd.dy * -1


    if (dvd.xcor() >= 285) and (dvd.ycor() >= 235):
        cornerhits = cornerhits + 1
        pen.clear()
        pen.write("Corner Hits: {}".format(cornerhits), font=("arial", 24))

    if (dvd.xcor() >= 285) and (dvd.ycor() <= -225):
        cornerhits = cornerhits + 1
        pen.clear()
        pen.write("Corner Hits: {}".format(cornerhits), font=("arial", 24))

    if (dvd.xcor() <= -285) and (dvd.ycor() >= 235):
        cornerhits = cornerhits + 1
        pen.clear()
        pen.write("Corner Hits: {}".format(cornerhits), font=("arial", 24))

    if (dvd.xcor() <= -285) and (dvd.ycor() <= -225):
        cornerhits = cornerhits + 1
        pen.clear()
        pen.write("Corner Hits: {}".format(cornerhits), font=("arial", 24))
